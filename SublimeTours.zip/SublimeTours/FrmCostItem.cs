﻿// -----------------------
// Author: Rorie McPherson
// Date: 10 June 2014
// -----------------------

// This form is presented if the user has chosen to add or edit a cost item from the tour form. This form responds
// differently depending on the cost item type selected by the user in the tour form. The only input from the user
// that this form is responsible for assigning to a cost item is the description and amount for the cost item. When
// The 'OK' button is pressed in this form, some basic data validation is carried out to check if the description
// textbox is not left empty. This form will then recieve a response from the form responsible for making the specific
// cost item, e.g. FrmStaff, on whether the textboxes in that form are also valid, before permitting the new data 
// for the cost item to be set. 

using System;
using System.Windows.Forms;

namespace SublimeTours
{
    public partial class FrmCostItem : Form
    {

        protected ClsCostItem _CostItem;

        public FrmCostItem()
        {
            InitializeComponent();
        }

        public bool ShowDialog(ClsCostItem prCostItem)
        {
            _CostItem = prCostItem;
            UpdateDisplay();
            return ShowDialog() == DialogResult.OK;
        }

        protected virtual void UpdateDisplay()
        {
            txtDescription.Text = _CostItem.Description;
            numAmountEntered.Value = _CostItem.AmountEntered;
        }

        protected virtual void PushData()
        {
            _CostItem.Description = txtDescription.Text.Trim();
            _CostItem.AmountEntered = numAmountEntered.Value;
            _CostItem.Type = _CostItem.GetCostType();
        }

        protected virtual bool TextboxesValid()
        {
            return true;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtDescription.Text.Trim()))
            {
                MessageBox.Show("Please enter a description for the cost item.", "Please Enter Description");
            }
            else if (TextboxesValid())
            {
                PushData();
                DialogResult = DialogResult.OK;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
