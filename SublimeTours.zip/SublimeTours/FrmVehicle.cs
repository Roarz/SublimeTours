﻿// -----------------------
// Author: Rorie McPherson
// Date: 10 June 2014
// -----------------------

// This form is presented if the user has chosen to add or edit a vehicle cost item. This form is responsible for
// grabbing the model and brand of a vehicle from the model and brand textboxes on this form. These values are 
// then stored in the vehicle cost item object.

// Some simple validation is also carried out to ensure that the brand and model textboxes have not been left empty.

using System;
using System.Windows.Forms;

namespace SublimeTours
{
    public partial class FrmVehicle : SublimeTours.FrmCostItem
    {
        
        public FrmVehicle()
        {
            InitializeComponent();
        }

        protected override void PushData()
        {
            base.PushData();
            ClsVehicle lcCostItem = (ClsVehicle)_CostItem;
            lcCostItem.Brand = txtBrand.Text.Trim();
            lcCostItem.Model = txtModel.Text.Trim();
        }

        protected override void UpdateDisplay()
        {
            base.UpdateDisplay();
            ClsVehicle lcCostItem = (ClsVehicle)_CostItem;
            txtBrand.Text = lcCostItem.Brand;
            txtModel.Text = lcCostItem.Model;
        }

        protected override bool TextboxesValid()
        {
            base.TextboxesValid();
            if (String.IsNullOrEmpty(txtModel.Text.Trim()))
            {
                MessageBox.Show("Please enter model for the vehicle.", "Please Enter Vehicle Model");
                return false;
            }
            else if (String.IsNullOrEmpty(txtBrand.Text.Trim()))
            {
                MessageBox.Show("Please enter a brand for the vehicle.", "Please Enter Vehicle Brand");
                return false;
            }
            else
            {
                return true;
            }

        }
    }
}
