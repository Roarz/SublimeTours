﻿// -----------------------
// Author: Rorie McPherson
// Date: 10 June 2014
// -----------------------

// This class is used to structure a cost item that is of type other. An "other" cost item does not add any 
// additional properties to a cost item. When an other cost object is created, the static form of type 
// FrmOther is shown as a dialog to recieve input required for the object. This is only a description and
// the amount entered.

// This cost item is also responsible for calculating its total cost. For an other cost item, the total cost is 
// exactly the same as the amount entered by the user.

using System;

namespace SublimeTours
{
    [Serializable]
    public class ClsOther : ClsCostItem
    {

        private static FrmOther _Form = new FrmOther();

        public override bool EditCostItem()
        {
            return _Form.ShowDialog(this);
        }
        public override string GetCostType()
        {
            return "Other";
        }
        public override decimal CalculateCostItemTotal(ClsTour prTour)
        {
            CostTotal = AmountEntered;
            return CostTotal;
        }

        
    }
}
