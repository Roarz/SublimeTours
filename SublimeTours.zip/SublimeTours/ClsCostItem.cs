﻿// -----------------------
// Author: Rorie McPherson
// Date: 10 June 2014
// -----------------------

// This class is used to outline the similarities that all cost items share. Every cost item has a description,
// type, amount entered, and total cost for the cost item. This class has a static array of the possible cost types
// available to choose from. This includes vehicle cost, staff cost and other cost. A factory method named 
// NewCostItem in this class is responsible for selecting which type of cost should be created.

// This class has abstract methods for editing the cost item, getting the type of the cost item and calculating 
// the cost item total. Each different cost item must override these methods. By overriding these abstract 
// methods, each different type of cost item is able to respond differently to the same message.

using System;

namespace SublimeTours
{
    [Serializable]
    public abstract class ClsCostItem
    {
        public static string[] CostType = { "Vehicle", "Staff", "Other" };

        private string _Description;
        private string _Type;
        private decimal _AmountEntered = 1;
        private decimal _CostTotal;

        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }

        public string Type
        {
            get { return _Type; }
            set { _Type = value; }
        }

        public decimal AmountEntered
        {
            get { return _AmountEntered; }
            set { _AmountEntered = value; }
        }

        public decimal CostTotal
        {
            get { return _CostTotal; }
            set { _CostTotal = value; }
        }

        public static ClsCostItem NewCostItem(int prChoice)
        {
            if (prChoice == 0)
                return new ClsVehicle();
            else if (prChoice == 1)
                return new ClsStaff();
            else
                return new ClsOther();
        }

        public abstract bool EditCostItem();
        public abstract string GetCostType();
        public abstract decimal CalculateCostItemTotal(ClsTour prTour);



    }
}
