﻿// -----------------------
// Author: Rorie McPherson
// Date: 10 June 2014
// -----------------------

// This form is presented if the user has chosen to add or edit a staff cost item. This form is responsible for
// grabbing the name of the staff member from the txtStaffName textbox on this form. This value is then stored
// in the staff cost item object.

// Some simple validation is also carried out to ensure that the staff name textbox has not been left empty.

using System;
using System.Windows.Forms;

namespace SublimeTours
{
    public partial class FrmStaff : SublimeTours.FrmCostItem
    {

        public FrmStaff()
        {
            InitializeComponent();
        }

        protected override void PushData()
        {
            base.PushData();
            ClsStaff lcCostItem = (ClsStaff)_CostItem;
            lcCostItem.StaffName = txtStaffName.Text.Trim();
        }

        protected override void UpdateDisplay()
        {
            base.UpdateDisplay();
            ClsStaff lcCostItem = (ClsStaff)_CostItem;
            txtStaffName.Text = lcCostItem.StaffName;
        }

        protected override bool TextboxesValid()
        {
            base.TextboxesValid();
            if (String.IsNullOrEmpty(txtStaffName.Text.Trim()))
            {
                MessageBox.Show("Please enter the name of the staff member.", "Please Enter Staff Name");
                return false;
            }
            else
            {
                return true;
            }
            
        }
    }
}
