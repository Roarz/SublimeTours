﻿// -----------------------
// Author: Rorie McPherson
// Date: 10 June 2014
// -----------------------

// This class is used to structure a tour object. The properties of a tour include tour code, tour name, start and
// end dates, maximum passengers, travel distance, mark up, price per passenger, and total of all costs. Each tour 
// also has a list of cost items. This class is also responsible for calculating the total of all costs as
// well as calculating the price per passenger. The results of these calculations are stored in the appropriate
// propertes for the tour (i.e. price per passenger and total of all costs).


using System;
using System.Collections.Generic;

namespace SublimeTours
{
    [Serializable] 
    public class ClsTour
    {
        
        private List<ClsCostItem> _CostList = new List<ClsCostItem>(); // Every tour has its own list of costs.
        private string _Code;
        private string _Name;
        private DateTime _StartDate = DateTime.Today;
        private DateTime _EndDate = DateTime.Today.AddDays(5);
        private decimal _MaximumPassengers = 20;
        private decimal _TravelDistance = 100;
        private decimal _MarkUp = 100;
        private decimal _PricePerPassenger;
        private decimal _TotalOfAllCosts;

        public List<ClsCostItem> CostList
        {
            get { return _CostList; }
            set { _CostList = value; }
        }
        
        public string Code
        {
            get { return _Code; }
            set { _Code = value; }
        }
        
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        
        public DateTime StartDate
        {
            get { return _StartDate; }
            set { _StartDate = value; }
        }
        
        public DateTime EndDate
        {
            get { return _EndDate; }
            set { _EndDate = value; }
        }
        
        public decimal MaximumPassengers
        {
            get { return _MaximumPassengers; }
            set { _MaximumPassengers = value; }
        }
        
        public decimal TravelDistance
        {
            get { return _TravelDistance; }
            set { _TravelDistance = value; }
        }
        
        public decimal MarkUp
        {
            get { return _MarkUp; }
            set { _MarkUp = value; }
        }
        
        public decimal PricePerPassenger
        {
            get { return _PricePerPassenger; }
            set { _PricePerPassenger = value; }
        }

        public decimal TotalOfAllCosts
        {
            get { return _TotalOfAllCosts; }
            set { _TotalOfAllCosts = value; }
        }

        //Methods
        public decimal CalculateTotalOfAllCosts()
        {
            decimal lcTotal = 0;
            foreach (ClsCostItem lcCostItem in _CostList)
                lcTotal += lcCostItem.CostTotal;
            return lcTotal;
        }

        public decimal CalculatePricePerPassenger()
        {
            decimal lcTotal = 0;
            decimal lcMarkUp = (_MarkUp/100)+1;
            decimal lcPassengers = _MaximumPassengers;
            decimal lcTotalOfAllCosts = CalculateTotalOfAllCosts();
            lcTotal = (lcTotalOfAllCosts / lcPassengers) * lcMarkUp;
            return lcTotal;
        }

        public bool TourDaysValid()
        {
            int lcTourDays = Convert.ToInt32((_EndDate - _StartDate).TotalDays);
            if (lcTourDays < 0)
            {
                System.Windows.Forms.MessageBox.Show("Please ensure the end date is not before the start date", "End date invalid");
                return false;
            }
            else
            {
                return true;
            }
            
        }
    }
}
