﻿// -----------------------
// Author: Rorie McPherson
// Date: 10 June 2014
// -----------------------

// This class is used to structure a vehicle cost item. A vehicle cost item adds two additonal properties
// of brand and model. When a vehicle cost is created, the static form of type FrmVehicle is shown as a 
// dialog to recieve input required for the object.

// This cost item is also responsible for calculating its total cost. For a vehicle cost item, we need
// to use the travel distance of the tour and multiply this value with the KM charge for the vehicle 
// object.

using System;

namespace SublimeTours
{
    [Serializable]
    public class ClsVehicle : ClsCostItem
    {

        private static FrmVehicle _Form = new FrmVehicle(); 
        private string _Brand;
        private string _Model;
        
        public string Brand
        {
            get { return _Brand; }
            set { _Brand = value; }
        }
        
        public string Model
        {
            get { return _Model; }
            set { _Model = value; }
        }

        public override bool EditCostItem()
        {
            return _Form.ShowDialog(this);
        }

        public override string GetCostType()
        {
            return "Vehicle";
        }

        public override decimal CalculateCostItemTotal(ClsTour prTour)
        {
            return CostTotal = AmountEntered * prTour.TravelDistance;
        }

    }
}
