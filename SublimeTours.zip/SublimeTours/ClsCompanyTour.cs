﻿// -----------------------
// Author: Rorie McPherson
// Date: 10 June 2014
// -----------------------

// This class is responsible for maintaining a dictionary of all of the tours created for the company.
// The dictionary is static meaning that there is only ever one dictionary. It is also public meaning
// the dictionary is visible to other classes. This means that other classes can manipulate the data
// stored in the dictionary. For example, the main form is able to add, edit and delete tours from 
// the dictionary.

// All of the tours are stored persistantly. This means that they still exist after the program has 
// finished running. Two methods, save and retrieve, are used to create, retrieve and update the tours 
// that are stored persistantly.

using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace SublimeTours
{
    class ClsCompanyTour
    {
        private static string fileName = @"SublimeTours.dat";

        private static Dictionary<string, ClsTour> _TourDictionary =
                            new Dictionary<string, ClsTour>();
        
        public static Dictionary<string, ClsTour> TourDictionary
        {
            get { return ClsCompanyTour._TourDictionary; }
        }

        public static void Save()
        {
            using (FileStream lcFileStream = new FileStream(fileName, FileMode.Create))
            {
                BinaryFormatter lcFormatter = new BinaryFormatter();
                lcFormatter.Serialize(lcFileStream, _TourDictionary);
            }
        }

        public static void Retrieve()
        {
            using (FileStream lcFileStream = new FileStream(fileName, FileMode.Open))
            {
                BinaryFormatter lcFormatter = new BinaryFormatter();
                _TourDictionary = (Dictionary<string, ClsTour>)
                                lcFormatter.Deserialize(lcFileStream);
            }
        }

    }
}
