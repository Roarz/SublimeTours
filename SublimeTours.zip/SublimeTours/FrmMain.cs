﻿// -----------------------
// Author: Rorie McPherson
// Date: 10 June 2014
// -----------------------

// This form is the first form that is presented to the user. It shows all of the tours for the company in a datagrid
// and allows the user to either add a tour, edit a tour, or delete a tour. The user can also sort the tours by either 
// name or start date. From this form, the user is able to see the code, name, start date and price per passenger for 
// the tour. If the tours have identical start dates, they will be further sorted by tour name. If tours have the same 
// tour name, they will be further sorted by start date.

// After the user either adds, edits, deletes a tour, or changes the sort order of a tour, the data grid that displays 
// the tours will be updated to reflect the changes.

// When this form starts, it checks to see whether a database file containing all of the tours exists. If so, these
// tours will be retrieved and added to the datagrid of tours on this form. If it doesn't exist, a new database 
// file will be created. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace SublimeTours
{

    public partial class FrmMain : Form
    {
        private FrmTour _TourForm = new FrmTour(); // creating a new form of type FrmTour. FrmMain is the exclusive owner of this form.
        private readonly string[] _SortStrings = { "Name", "Start Date" };
        private IComparer<ClsTour>[] _Comparer = { new ClsNameComparer(), new ClsStartDateComparer() };

        //DOB Comparer For Sorting
        class ClsStartDateComparer : IComparer<ClsTour>
        {
            public int Compare(ClsTour prTourx, ClsTour prToury)
            {
                int lcResult = prTourx.StartDate.Date.CompareTo(prToury.StartDate.Date);
                if (lcResult != 0)
                {
                    return lcResult;
                }
                else
                {
                    return prTourx.Name.CompareTo(prToury.Name);
                }
            }
        }

        //Tour Name Comparer For Sorting
        class ClsNameComparer : IComparer<ClsTour>
        {
            public int Compare(ClsTour prTourx, ClsTour prToury)
            {
                int lcResult = prTourx.Name.CompareTo(prToury.Name);
                if (lcResult != 0)
                {
                    return lcResult;
                }
                else
                {
                    return prTourx.StartDate.Date.CompareTo(prToury.StartDate.Date);
                }
            }
        }

        public FrmMain()
        {
            InitializeComponent();
            cboSortTour.DataSource = _SortStrings;
            cboSortTour.SelectedIndex = 0;

            try
            {
                ClsCompanyTour.Retrieve();
                RefreshTourList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); // if retrieving was not successful, a message box will be displayed to the user showing the exception details.
            }
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            RefreshTourList(); // All of the tours in the tour dictionary will be placed in the datagrid.
            FormatDataGrid(); //  The data grid will be tidied up. This only needs to happen once.
        }

        private void btnAddTour_Click(object sender, EventArgs e)
        {
            ClsTour lcTour = new ClsTour(); // Creating a new instance of ClsTour.
            _TourForm.ShowDialog(lcTour);
            if (lcTour != null && _TourForm.DialogResult == DialogResult.OK)
            {
                ClsCompanyTour.TourDictionary.Add(lcTour.Code, lcTour);
                RefreshTourList();
            }
        }

        private void btnEditTour_Click(object sender, EventArgs e)
        {
            EditTour();
        }

        private void Tour_DoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            EditTour();
        }

        private void EditTour()
        {
            ClsTour lcTour = (ClsTour)dgvTour.CurrentRow.DataBoundItem;
            _TourForm.ShowDialog(lcTour);
            RefreshTourList();
        }

        private void btnDeleteTour_Click(object sender, EventArgs e)
        {
            ClsTour lcTour = (ClsTour)dgvTour.CurrentRow.DataBoundItem;
            DialogResult lcDeleteTourResult = MessageBox.Show("Are you sure you would like to delete tour: " + lcTour.Code + "?",
                "Confirm Delete", MessageBoxButtons.YesNo);
            if (lcDeleteTourResult == DialogResult.Yes)
            {
                ClsCompanyTour.TourDictionary.Remove(lcTour.Code);
                RefreshTourList();
            }
        }

        private void cboSortTour_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshTourList();
        }

        private void RefreshTourList()
        {
            List<ClsTour> lcTourDictionary = ClsCompanyTour.TourDictionary.Values.ToList(); // Grabs all of the tours from the dictionary of tours and places them in a list.
            lcTourDictionary.Sort(_Comparer[cboSortTour.SelectedIndex]); // Sorts the list of tours based on the sorting option the user has chosen in the combobox.
            dgvTour.DataSource = lcTourDictionary; // Uses all of the entries in the list of tours variable to populate the data grid.
            
            int lcTourCount = ClsCompanyTour.TourDictionary.Count;
            if (lcTourCount == 0)
            {
                btnEditTour.Enabled = false; // disables the edit and delete tour buttons if none exist.
                btnDeleteTour.Enabled = false;
            }   
            else
            {
                btnEditTour.Enabled = true;
                btnDeleteTour.Enabled = true;
            }
        }

        private void FormatDataGrid()
        {
            // Formatting the columns of the datagrid for presentation purposes.
            dgvTour.Columns[7].Width = 80;
            dgvTour.Columns[2].Width = 50;

            dgvTour.Columns[0].HeaderText = "Tour Code"; // renaming the column headers for better readability
            dgvTour.Columns[1].HeaderText = "Tour Name";
            dgvTour.Columns[2].HeaderText = "Start Date";
            dgvTour.Columns[7].HeaderText = "Price Per Passenger";
            dgvTour.Columns[7].DefaultCellStyle.Format = "c"; // setting the price per passenger column to currency format.
            dgvTour.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Changing the alignment of the currency column to the right rather than the left.

            dgvTour.Columns[3].Visible = false; // hiding columns we do not want to see about the tour.
            dgvTour.Columns[4].Visible = false;
            dgvTour.Columns[5].Visible = false;
            dgvTour.Columns[6].Visible = false;
            dgvTour.Columns[8].Visible = false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            try
            {
                ClsCompanyTour.Save();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); // if saving is not successful, a message box will be displayed to the user showing the exception details.
            }
            Close();
        }
        
    }

    
}
