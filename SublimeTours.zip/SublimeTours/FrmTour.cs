﻿// -----------------------
// Author: Rorie McPherson
// Date: 10 June 2014
// -----------------------

// This form is presented if the user has chosen to add or edit a tour from the main form. This form shows details for
// the selected tour including tour code, tour name, start date, mark up percentage, price per passenger and the total
// cost of all cost items. If the user changes the value from any of the controls used for calculating the total of all 
// costs or price per passenger (everything except tour name and tour code), these two properties will need to be 
// re-calculated. The cost items are then updated to reflect these changes.

// Please note that a combination of "key up" and "mouse down" events have been used to recalculate price per 
// passenger and total of all costs. An event for recognising when either the start or end date calenders have 
// been used also recalculates the total of all costs and price per passenger.

using System;
using System.Linq;
using System.Windows.Forms;

namespace SublimeTours
{
    public partial class FrmTour : Form
    {

        private ClsTour _Tour;

        public FrmTour()
        {
            InitializeComponent();
            cboCostItemType.DataSource = ClsCostItem.CostType;
            cboCostItemType.SelectedIndex = 0;
        }

        public DialogResult ShowDialog(ClsTour prTour)
        {
            _Tour = prTour;
            UpdateDisplay();
            txtCode.Enabled = String.IsNullOrEmpty(_Tour.Code); // Tour code is only disabled if it contains a value. It can only contain a value if an exiting tour is being edited.
            return ShowDialog();
        }

        private void FrmTour_Load(object sender, EventArgs e)
        {
            RefreshCostList();
            dgvTourCost.Columns[3].DefaultCellStyle.Format = "c";
            dgvTourCost.Columns[2].DefaultCellStyle.Format = "c";
            dgvTourCost.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvTourCost.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        private void btnAddCostItem_Click(object sender, EventArgs e)
        {
            ClsCostItem lcCostItem = ClsCostItem.NewCostItem(cboCostItemType.SelectedIndex);
            if (lcCostItem != null && lcCostItem.EditCostItem())
            {
                _Tour.CostList.Add(lcCostItem);
                RefreshCostList();
            }
        }

        private void btnEditCostItem_Click(object sender, EventArgs e)
        {
            EditCostItem();
        }

        private void CostItem_DoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            EditCostItem();
        }

        private void EditCostItem()
        {
            ClsCostItem lcCostItem = (ClsCostItem)dgvTourCost.CurrentRow.DataBoundItem;
            lcCostItem.EditCostItem();
            RefreshCostList(); 
        }

        private void btnDeleteCostItem_Click(object sender, EventArgs e)
        {
            ClsCostItem lcCostItem = (ClsCostItem)dgvTourCost.CurrentRow.DataBoundItem;
            DialogResult DeleteCostResult = MessageBox.Show("Are you sure you would like to delete cost item: " + lcCostItem.Description + "?",
                "Confirm Delete", MessageBoxButtons.YesNo);
            if (DeleteCostResult == DialogResult.Yes)
            {
                _Tour.CostList.Remove(lcCostItem);
                RefreshCostList();
                UpdateDisplay(); // Updating the display incase the only cost item for that tour is deleted.
            }
            
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtCode.Enabled && ClsCompanyTour.TourDictionary.ContainsKey(txtCode.Text.Trim()))
            {
                MessageBox.Show("A Tour with that code already exists", "Duplicate Tour Code");
            }

            else if (txtCode.Text.Trim() == "")
            {
                MessageBox.Show("Please ensure the tour has a code", "Enter a Tour Code");
            }

            else if (txtName.Text.Trim() == "")
            {
                MessageBox.Show("Please ensure the tour has a name", "Enter a Tour Name");
            }

            else
            {
                RefreshCostList();
                GrabTourData();
                if (_Tour.TourDaysValid())
                {
                    DialogResult = DialogResult.OK;
                }
            }
        }

        private void GrabTourData()
        {
            _Tour.Code = txtCode.Text.Trim();
            _Tour.Name = txtName.Text.Trim();
            _Tour.StartDate = dtpStartDate.Value;
            _Tour.EndDate = dtpEndDate.Value;
            _Tour.MaximumPassengers = numMaximumPassengers.Value;
            _Tour.TravelDistance = numTravelDistance.Value;
            _Tour.MarkUp = numCostMarkUp.Value;
            _Tour.PricePerPassenger = _Tour.CalculatePricePerPassenger();
            _Tour.TotalOfAllCosts = _Tour.CalculateTotalOfAllCosts();
        }

        private void UpdateDisplay()
        {
            txtCode.Text = _Tour.Code;
            txtName.Text = _Tour.Name;
            dtpStartDate.Value = _Tour.StartDate;
            dtpEndDate.Value = _Tour.EndDate;
            numMaximumPassengers.Value = _Tour.MaximumPassengers;
            numTravelDistance.Value = _Tour.TravelDistance;
            numCostMarkUp.Value = _Tour.MarkUp;
            lblTotalAllCosts.Text = string.Format("{1:C}", 0, _Tour.CalculateTotalOfAllCosts());
            lblPricePerPassenger.Text = string.Format("{1:C}", 0, _Tour.CalculatePricePerPassenger());
        }

        private void RefreshCostList()
        {
            GrabTourData();

            int lcCostItemCount = _Tour.CostList.Count;
            dgvTourCost.DataSource = _Tour.CostList.ToList();

            if (lcCostItemCount == 0)
            {
                btnEditCostItem.Enabled = false;
                btnDeleteCostItem.Enabled = false;
            }
            else
            {
                btnEditCostItem.Enabled = true;
                btnDeleteCostItem.Enabled = true;

                foreach (ClsCostItem lcCostItem in _Tour.CostList)
                {
                    lcCostItem.CalculateCostItemTotal(_Tour);
                }
            }

            UpdateDisplay();
        }

        private void ControlsForCalculation_KeyUp(object sender, KeyEventArgs e)
        {
            RefreshCostList();
        }

        private void dtpCalender_CloseUp(object sender, EventArgs e)
        {
            RefreshCostList();
        }

        private void ControlsForCalculation_MouseDown(object sender, MouseEventArgs e)
        {
            RefreshCostList();
        }

    }

}
