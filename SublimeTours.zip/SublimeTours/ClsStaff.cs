﻿// -----------------------
// Author: Rorie McPherson
// Date: 10 June 2014
// -----------------------

// This class is used to structure a staff cost item. A staff cost item adds an additonal property
// of staff name. When a staff cost is created, the static form of type FrmStaff is shown as a 
// dialog to recieve input required for the object.

// This cost item is also responsible for calculating its total cost. For a staff cost item, we need
// to calculate how many days are between the start and end dates. The number of days is then multiplied
// by the daily rate charge for the staff object. Note that 1 is always added onto the number of days.
// This is to ensure that staff are paid even if the tour starts and ends on the same date.

using System;

namespace SublimeTours
{
    [Serializable]
    public class ClsStaff : ClsCostItem
    {

        private static FrmStaff _Form = new FrmStaff();
        private string _StaffName;

        public string StaffName
        {
            get { return _StaffName; }
            set { _StaffName = value; }
        }

        public override bool EditCostItem()
        {
            return _Form.ShowDialog(this);
        }
        public override string GetCostType()
        {
            return "Staff";
        }
        public override decimal CalculateCostItemTotal(ClsTour prTour)
        {
            decimal lcTourDays = Convert.ToDecimal((prTour.EndDate.Date - prTour.StartDate.Date).TotalDays) + 1;
            CostTotal = AmountEntered * lcTourDays;
            return CostTotal;
        }
    }
}
