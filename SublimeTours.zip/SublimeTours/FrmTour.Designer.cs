﻿namespace SublimeTours
{
    partial class FrmTour
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.numMaximumPassengers = new System.Windows.Forms.NumericUpDown();
            this.numTravelDistance = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblTotalAllCosts = new System.Windows.Forms.Label();
            this.numCostMarkUp = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.lblPricePerPassenger = new System.Windows.Forms.Label();
            this.btnAddCostItem = new System.Windows.Forms.Button();
            this.cboCostItemType = new System.Windows.Forms.ComboBox();
            this.btnEditCostItem = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.btnDeleteCostItem = new System.Windows.Forms.Button();
            this.dgvTourCost = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.numMaximumPassengers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTravelDistance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCostMarkUp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTourCost)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tour Code:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Start Date:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "End Date:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 133);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(144, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Maximum Passengers:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(13, 164);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Travel Distance:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(13, 196);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Cost Mark-Up:";
            // 
            // txtCode
            // 
            this.txtCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCode.Location = new System.Drawing.Point(168, 10);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(100, 22);
            this.txtCode.TabIndex = 6;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(168, 42);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 22);
            this.txtName.TabIndex = 9;
            this.txtName.Text = "Kaiteriteri";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(13, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 16);
            this.label7.TabIndex = 8;
            this.label7.Text = "Tour Name:";
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpStartDate.Location = new System.Drawing.Point(168, 73);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(200, 20);
            this.dtpStartDate.TabIndex = 10;
            this.dtpStartDate.Value = new System.DateTime(2014, 6, 1, 0, 0, 0, 0);
            this.dtpStartDate.CloseUp += new System.EventHandler(this.dtpCalender_CloseUp);
            this.dtpStartDate.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ControlsForCalculation_KeyUp);
            this.dtpStartDate.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ControlsForCalculation_MouseDown);
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpEndDate.Location = new System.Drawing.Point(168, 102);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(200, 20);
            this.dtpEndDate.TabIndex = 11;
            this.dtpEndDate.Value = new System.DateTime(2014, 6, 10, 0, 0, 0, 0);
            this.dtpEndDate.CloseUp += new System.EventHandler(this.dtpCalender_CloseUp);
            this.dtpEndDate.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ControlsForCalculation_KeyUp);
            this.dtpEndDate.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ControlsForCalculation_MouseDown);
            // 
            // numMaximumPassengers
            // 
            this.numMaximumPassengers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numMaximumPassengers.Location = new System.Drawing.Point(168, 131);
            this.numMaximumPassengers.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numMaximumPassengers.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numMaximumPassengers.Name = "numMaximumPassengers";
            this.numMaximumPassengers.Size = new System.Drawing.Size(100, 22);
            this.numMaximumPassengers.TabIndex = 12;
            this.numMaximumPassengers.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numMaximumPassengers.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numMaximumPassengers.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ControlsForCalculation_KeyUp);
            this.numMaximumPassengers.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ControlsForCalculation_MouseDown);
            // 
            // numTravelDistance
            // 
            this.numTravelDistance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numTravelDistance.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numTravelDistance.Location = new System.Drawing.Point(168, 162);
            this.numTravelDistance.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numTravelDistance.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numTravelDistance.Name = "numTravelDistance";
            this.numTravelDistance.Size = new System.Drawing.Size(100, 22);
            this.numTravelDistance.TabIndex = 13;
            this.numTravelDistance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numTravelDistance.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.numTravelDistance.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ControlsForCalculation_KeyUp);
            this.numTravelDistance.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ControlsForCalculation_MouseDown);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(268, 164);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 16);
            this.label8.TabIndex = 14;
            this.label8.Text = "KM";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(268, 196);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(20, 16);
            this.label9.TabIndex = 16;
            this.label9.Text = "%";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(12, 275);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 16);
            this.label10.TabIndex = 23;
            this.label10.Text = "Cost Items:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(9, 438);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(171, 16);
            this.label11.TabIndex = 27;
            this.label11.Text = "Total of All Costs Items:";
            // 
            // lblTotalAllCosts
            // 
            this.lblTotalAllCosts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalAllCosts.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalAllCosts.Location = new System.Drawing.Point(16, 456);
            this.lblTotalAllCosts.Name = "lblTotalAllCosts";
            this.lblTotalAllCosts.Size = new System.Drawing.Size(164, 31);
            this.lblTotalAllCosts.TabIndex = 28;
            this.lblTotalAllCosts.Text = "5040.00";
            this.lblTotalAllCosts.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numCostMarkUp
            // 
            this.numCostMarkUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numCostMarkUp.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numCostMarkUp.Location = new System.Drawing.Point(168, 194);
            this.numCostMarkUp.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.numCostMarkUp.Name = "numCostMarkUp";
            this.numCostMarkUp.Size = new System.Drawing.Size(100, 22);
            this.numCostMarkUp.TabIndex = 29;
            this.numCostMarkUp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numCostMarkUp.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numCostMarkUp.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ControlsForCalculation_KeyUp);
            this.numCostMarkUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ControlsForCalculation_MouseDown);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(13, 229);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(135, 16);
            this.label13.TabIndex = 30;
            this.label13.Text = "Price Per Passenger:";
            // 
            // lblPricePerPassenger
            // 
            this.lblPricePerPassenger.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPricePerPassenger.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPricePerPassenger.Location = new System.Drawing.Point(168, 222);
            this.lblPricePerPassenger.Name = "lblPricePerPassenger";
            this.lblPricePerPassenger.Size = new System.Drawing.Size(100, 31);
            this.lblPricePerPassenger.TabIndex = 31;
            this.lblPricePerPassenger.Text = "504";
            this.lblPricePerPassenger.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnAddCostItem
            // 
            this.btnAddCostItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCostItem.Location = new System.Drawing.Point(427, 326);
            this.btnAddCostItem.Name = "btnAddCostItem";
            this.btnAddCostItem.Size = new System.Drawing.Size(124, 29);
            this.btnAddCostItem.TabIndex = 32;
            this.btnAddCostItem.Text = "Add Cost Item";
            this.btnAddCostItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddCostItem.UseVisualStyleBackColor = true;
            this.btnAddCostItem.Click += new System.EventHandler(this.btnAddCostItem_Click);
            // 
            // cboCostItemType
            // 
            this.cboCostItemType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCostItemType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboCostItemType.FormattingEnabled = true;
            this.cboCostItemType.Location = new System.Drawing.Point(427, 296);
            this.cboCostItemType.Name = "cboCostItemType";
            this.cboCostItemType.Size = new System.Drawing.Size(124, 24);
            this.cboCostItemType.TabIndex = 33;
            // 
            // btnEditCostItem
            // 
            this.btnEditCostItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditCostItem.Location = new System.Drawing.Point(427, 361);
            this.btnEditCostItem.Name = "btnEditCostItem";
            this.btnEditCostItem.Size = new System.Drawing.Size(124, 29);
            this.btnEditCostItem.TabIndex = 34;
            this.btnEditCostItem.Text = "Edit Cost Item";
            this.btnEditCostItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEditCostItem.UseVisualStyleBackColor = true;
            this.btnEditCostItem.Click += new System.EventHandler(this.btnEditCostItem_Click);
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.Location = new System.Drawing.Point(427, 458);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(124, 29);
            this.btnOK.TabIndex = 37;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(425, 275);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(131, 16);
            this.label15.TabIndex = 38;
            this.label15.Text = "New Cost Item Type:";
            // 
            // btnDeleteCostItem
            // 
            this.btnDeleteCostItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteCostItem.Location = new System.Drawing.Point(427, 396);
            this.btnDeleteCostItem.Name = "btnDeleteCostItem";
            this.btnDeleteCostItem.Size = new System.Drawing.Size(124, 29);
            this.btnDeleteCostItem.TabIndex = 40;
            this.btnDeleteCostItem.Text = "Delete Cost Item";
            this.btnDeleteCostItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeleteCostItem.UseVisualStyleBackColor = true;
            this.btnDeleteCostItem.Click += new System.EventHandler(this.btnDeleteCostItem_Click);
            // 
            // dgvTourCost
            // 
            this.dgvTourCost.AllowUserToAddRows = false;
            this.dgvTourCost.AllowUserToDeleteRows = false;
            this.dgvTourCost.AllowUserToResizeColumns = false;
            this.dgvTourCost.AllowUserToResizeRows = false;
            this.dgvTourCost.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTourCost.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvTourCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTourCost.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTourCost.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTourCost.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTourCost.GridColor = System.Drawing.SystemColors.ScrollBar;
            this.dgvTourCost.Location = new System.Drawing.Point(15, 296);
            this.dgvTourCost.MultiSelect = false;
            this.dgvTourCost.Name = "dgvTourCost";
            this.dgvTourCost.ReadOnly = true;
            this.dgvTourCost.RowHeadersVisible = false;
            this.dgvTourCost.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTourCost.Size = new System.Drawing.Size(406, 129);
            this.dgvTourCost.TabIndex = 41;
            this.dgvTourCost.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.CostItem_DoubleClick);
            // 
            // FrmTour
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 499);
            this.ControlBox = false;
            this.Controls.Add(this.dgvTourCost);
            this.Controls.Add(this.btnDeleteCostItem);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnEditCostItem);
            this.Controls.Add(this.cboCostItemType);
            this.Controls.Add(this.btnAddCostItem);
            this.Controls.Add(this.lblPricePerPassenger);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.numCostMarkUp);
            this.Controls.Add(this.lblTotalAllCosts);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.numTravelDistance);
            this.Controls.Add(this.numMaximumPassengers);
            this.Controls.Add(this.dtpEndDate);
            this.Controls.Add(this.dtpStartDate);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FrmTour";
            this.Text = "FrmTour";
            this.Load += new System.EventHandler(this.FrmTour_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numMaximumPassengers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTravelDistance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCostMarkUp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTourCost)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.NumericUpDown numMaximumPassengers;
        private System.Windows.Forms.NumericUpDown numTravelDistance;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblTotalAllCosts;
        private System.Windows.Forms.NumericUpDown numCostMarkUp;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblPricePerPassenger;
        private System.Windows.Forms.Button btnAddCostItem;
        private System.Windows.Forms.ComboBox cboCostItemType;
        private System.Windows.Forms.Button btnEditCostItem;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnDeleteCostItem;
        private System.Windows.Forms.DataGridView dgvTourCost;
    }
}