﻿// -----------------------
// Author: Rorie McPherson
// Date: 10 June 2014
// -----------------------

// This form is presented if the user has chosen to add or edit a cost item of type "other". This form
// does not have any additional textboxes as an other cost object does not require any additonal properties.

// Some simple validation is carried out on the parent form to ensure that the description of an other cost
// has not been left empty.

namespace SublimeTours
{
    public partial class FrmOther : SublimeTours.FrmCostItem
    {

        public FrmOther()
        {
            InitializeComponent();
        }
    }
}
